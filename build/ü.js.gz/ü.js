var \u00fc=function(a){return a.replace(/[aeiou]/g,function(a){return{a:"ä",e:"ë",i:"ï",o:"ö",u:"ü"}[a]||a})};\u00fc.n\u0308=function(a){return a<11?11:a};
